<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Surah extends Model
{
    //
}
