<!-- <script src="https://code.jquery.com/jquery-3.3.1.js"></script> -->
<!-- <script src="{{asset('js/jquery.min.js')}}"></script> -->

<!-- Bootstrap Core JavaScript -->
<script src="{{asset('public/js/bootstrap.min.js')}}"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="{{asset('public/js/metisMenu.min.js')}}"></script>

<!-- Custom Theme JavaScript -->
<script src="{{asset('public/js/sb-admin-2.js')}}"></script>

<!-- Additional Functions -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
<script src="{{asset('public/assets/summernote/summernote.js')}}"></script>

<script type="text/javascript">
	$(document).ready(function() {
	    $('#example').DataTable();

	    $('.summernote').summernote();
	});
</script>