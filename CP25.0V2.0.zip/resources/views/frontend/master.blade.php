@include('frontend/header')
@include('frontend/navigation')
@yield('content')
@include('frontend/footer')