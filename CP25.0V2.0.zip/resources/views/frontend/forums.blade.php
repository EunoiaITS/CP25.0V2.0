@extends('frontend.master')

@section('content')

	

@endsection