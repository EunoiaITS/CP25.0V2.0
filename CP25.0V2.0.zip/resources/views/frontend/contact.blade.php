@extends('frontend.master')

@section('content')

	<div class="container-fluid">
    <div class="col-md-6 top10 col-md-offset-3">
        <h3>Contact Us</h3>

        <div class="row">


            <a href="tel:+6067986675">Tel: +606-798 6675/6676</a><br>
            <a href="tel:+6067986677">Fax: +606-798 6677</a><br>
            <h4>
                6th Floor Tamhidi Center<br>
                Institut Sains Islam<br>
                Universiti Sains Islam Malaysia<br>
                Bandar Baru Nilai<br>
                71800<br>
                Nilai<br>Negeri Sembilan<br>MALAYSIA

            </h4>



            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.9199948903256!2d101.78149031475655!3d2.8394179979317298!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cdc663a9f84bf1%3A0x6c109d4708775b41!2sTAMHIDI!5e0!3m2!1sen!2sbd!4v1544782751888" width="700" height="440" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
        <!-- Col Md 8 -->

    </div>
    <!-- container fluid ends -->

@endsection