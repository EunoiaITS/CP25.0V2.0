<!DOCTYPE HTML>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Email Testing</title>
    </head>

    <body>
        <h1>{{ $title }}</h1>

        <p>{{ $content }}</p>
    </body>
</html>