<?php $__env->startSection('content'); ?>

	<?php
		$article = $page_data['article'];
		$details = ['author' => '', 'url' => '', 'disease_1' => '', 'disease_2' => '', 'abstract' => '', 'concept' => ''];
				      			
		foreach($article->details()->get() as $detail)
			$details[$detail->key] = $detail->value;
	?>

	<ol class="breadcrumb">
	  	<li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
	  	<li><a href="<?php echo e(url('/admin/articles')); ?>">Scientific Articles</a></li>
	  	<li class="active">Edit Scientific Article</li>
	</ol>

	<div class="row">
	    <div class="col-md-12">
	        <div class="panel panel-primary" data-collapsed="0">
	            <div class="panel-heading">
	                <div class="panel-title" >
	                    <i class="fa fa-plus-circle"></i>
	                    Edit Scientific Article
	                </div>
	            </div>
	            <div class="panel-body">

	            	<form action="<?php echo e(action('AdminArticlesController@update', $article->id)); ?>" method="post" class="form-horizontal form-groups-bordered">
	            		<?php echo method_field('PUT'); ?>
	            		<?php echo csrf_field(); ?>
	            		<div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Article Title / Name</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="title" value="<?php echo e($article->title); ?>"
	                            	autofocus="" required="">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Article Author / Publisher</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="author" value="<?php echo e($details['author']); ?>">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Article URL</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="url" value="<?php echo e($details['url']); ?>">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Disease 1</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="disease_1"
	                            	value="<?php echo e($details['disease_1']); ?>">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Disease 2</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="disease_2"
	                            	value="<?php echo e($details['disease_2']); ?>">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Abstract</label>

		                    <div class="col-sm-6">
	                            <textarea style="resize: vertical;" class="form-control" name="abstract"
	                            	rows="3"><?php echo e($details['abstract']); ?></textarea>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Concept</label>

		                    <div class="col-sm-6">
	                            <textarea style="resize: vertical;" class="form-control" name="concept"
	                            	rows="3"><?php echo e($details['concept']); ?></textarea>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <div class="col-sm-offset-3 col-sm-6">
		                        <button type="submit" class="btn btn-success">Update</button>
		                    </div>
		                </div>
	                </form>
	            </div>
	        </div>
	    </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>