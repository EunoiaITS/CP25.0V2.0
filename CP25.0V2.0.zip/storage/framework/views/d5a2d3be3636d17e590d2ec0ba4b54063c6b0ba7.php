<?php $__env->startSection('content'); ?>

	<?php
		$food    = $page_data['food'];
		$details = ['def_title' => '', 'definition' => '', 'desc_title' => '', 'description' => '', 'image' => ''];
				      			
		foreach($food->details()->get() as $detail)
			$details[$detail->key] = $detail->value;
	?>

	<ol class="breadcrumb">
	  	<li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
	  	<li><a href="<?php echo e(url('/admin/foods')); ?>">Prophetic Food</a></li>
	  	<li class="active">Edit Prophetic Food</li>
	</ol>

	<div class="row">
	    <div class="col-md-12">
	        <div class="panel panel-primary" data-collapsed="0">
	            <div class="panel-heading">
	                <div class="panel-title" >
	                    <i class="fa fa-plus-circle"></i>
	                    Edit Prophetic Food
	                </div>
	            </div>
	            <div class="panel-body">

	            	<form action="<?php echo e(action('AdminFoodsController@update', $food->id)); ?>" method="post"
	            		class="form-horizontal form-groups-bordered" enctype="multipart/form-data">
	            		<?php echo method_field('PUT'); ?>
	            		<?php echo csrf_field(); ?>
	            		<div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Food</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="title" value="<?php echo e($food->title); ?>"
	                        		autofocus="" required>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Arabic Translation</label>

		                    <div class="col-sm-6">
	                            <textarea style="resize: vertical;" class="form-control" name="trans_arabic"
	                            	rows="3"><?php echo e($food->trans_arabic); ?></textarea>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">English Translation</label>

		                    <div class="col-sm-6">
	                            <textarea style="resize: vertical;" class="form-control" name="trans_eng"
	                            	rows="3"><?php echo e($food->trans_eng); ?></textarea>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Malay Translation</label>

		                    <div class="col-sm-6">
	                            <textarea style="resize: vertical;" class="form-control" name="trans_malay"
	                            	rows="3"><?php echo e($food->trans_malay); ?></textarea>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Definition Title</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="def_title"
	                            	value="<?php echo e($details['def_title']); ?>">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Definition</label>

		                    <div class="col-sm-9">
	                            <textarea class="form-control summernote"
	                            	name="definition"><?php echo e($details['definition']); ?></textarea>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Description Title</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="desc_title"
	                            	value="<?php echo e($details['desc_title']); ?>">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Description</label>

		                    <div class="col-sm-9">
	                            <textarea class="form-control summernote"
	                            	name="description"><?php echo e($details['description']); ?></textarea>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Image</label>

		                    <?php if($details['image']): ?>
		                    	<div class="col-sm-3">
			                    	<img src="<?php echo e(url('/public/uploads') . '/' . $details['image']); ?>" height="100" alt="">
			                    </div>
	                    	<?php endif; ?>

		                    <div class="<?php if($details['image']) echo 'col-sm-offset-3'; ?> col-sm-6">
	                            <input type="file" name="image" accept="image/*" style="margin-top: 7px;">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <div class="col-sm-offset-3 col-sm-6">
		                        <button type="submit" class="btn btn-success">Update</button>
		                    </div>
		                </div>
	                </form>
	            </div>
	        </div>
	    </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>