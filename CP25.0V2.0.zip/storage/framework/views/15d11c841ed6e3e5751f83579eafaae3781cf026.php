<?php $__env->startSection('content'); ?>

	<ol class="breadcrumb">
	  	<li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
	  	<li class="active">Manage Users</li>
	</ol>

	<?php if(session()->has('success_message')): ?>
        <p class="alert alert-success">
            <?php echo e(session()->get('success_message')); ?>

        </p>
    <?php endif; ?>

	<a href="<?php echo e(url('/admin/users/create')); ?>" class="btn btn-primary pull-right" style="background: black;">
		<i class="fa fa-plus-circle"></i> Create New User
	</a>
	<div class="clearfix"></div><br>

	<?php if($page_data['users']->isEmpty()): ?>
		<p class="alert alert-info">
	        <?php echo e('No users found!'); ?>

	    </p>
    <?php else: ?>

		<div class="panel panel-primary">
			<div class="panel-heading">
	    		<h3 class="panel-title">Users List</h3>
	  		</div>
			<div class="panel-body">
				<div class="table-responsive">
					<table id="example" class="table table-striped" style="width:100%">
				    	<thead>
				      		<tr>
				        		<th>#</th>
				        		<th>Name</th>
				        		<th>Email</th>
				        		<th>Role</th>
				        		<th>Options</th>
				      		</tr>
				    	</thead>
				    	<tbody>
				    		<?php
				    		$count = 1;
				      		foreach($page_data['users'] as $user) { ?>
						      	<tr>
							        <td><?php echo $count++; ?></td>
							        <td><?php echo $user->name; ?></td>
							        <td><?php echo $user->email; ?></td>
							        <td><?php echo $user->role; ?></td>
							        <td>
							        	<?php if($user->role != 'admin'): ?>
							        		<a href="#" class="btn btn-sm btn-danger"
												onclick="confirm_modal_hard_reload('<?php echo action('AdminUsersController@destroy', $user->id); ?>');">
				                                Delete
				                            </a>
										<?php endif; ?>
						        	</td>
						      	</tr>
					      	<?php } ?>
				    	</tbody>
				  	</table>
				</div>
			</div>
		</div>
	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>