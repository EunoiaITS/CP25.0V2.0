<?php $__env->startSection('content'); ?>
        
    Welcome to your dashboard, <?php echo e(Auth::user()->name); ?> !!!

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>