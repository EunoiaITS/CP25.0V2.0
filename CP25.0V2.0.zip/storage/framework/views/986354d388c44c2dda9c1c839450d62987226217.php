<?php
    $page_name = $page_data['page_name'];
    $page_title = $page_data['page_title'];
?>

<!DOCTYPE HTML>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Naqli Aqli | <?php echo $page_title; ?></title>

        <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>

    <body>
        <div id="wrapper">
            <?php echo $__env->make(Auth::user()->role . '/navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header" style="margin-top: 20px;"><?php echo $page_title; ?></h1>
                    </div>
                </div>
                
                <?php echo $__env->yieldContent('content'); ?>

            </div>
        </div>

        <?php echo $__env->make('layouts/modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>