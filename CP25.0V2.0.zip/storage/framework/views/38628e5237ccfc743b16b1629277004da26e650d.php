<?php $__env->startSection('content'); ?>

	<?php
		$manuscript = $page_data['manuscript'];
		$details 	= ['manuscript_no' => '', 'bab' => '', 'page' => '', 'image' => ''];
				      			
		foreach($manuscript->details()->get() as $detail)
			$details[$detail->key] = $detail->value;
	?>

	<ol class="breadcrumb">
	  	<li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
	  	<li><a href="<?php echo e(url('/admin/manuscripts')); ?>">Manuscript</a></li>
	  	<li class="active">Edit Manuscript</li>
	</ol>

	<div class="row">
	    <div class="col-md-12">
	        <div class="panel panel-primary" data-collapsed="0">
	            <div class="panel-heading">
	                <div class="panel-title" >
	                    <i class="fa fa-plus-circle"></i>
	                    Edit Manuscript
	                </div>
	            </div>
	            <div class="panel-body">

	            	<form action="<?php echo e(action('AdminManuscriptsController@update', $manuscript->id)); ?>" method="post"
	            		class="form-horizontal form-groups-bordered" enctype="multipart/form-data">
	            		<?php echo method_field('PUT'); ?>
	            		<?php echo csrf_field(); ?>
		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Original Text</label>

		                    <div class="col-sm-6">
	                            <textarea style="resize: vertical;" class="form-control" name="trans_arabic"
	                            	rows="3" required><?php echo e($manuscript->trans_arabic); ?></textarea>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Manuscript (Malay)</label>

		                    <div class="col-sm-6">
	                            <textarea style="resize: vertical;" class="form-control" name="trans_malay"
	                            	rows="3"><?php echo e($manuscript->trans_malay); ?></textarea>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Manuscript (English)</label>

		                    <div class="col-sm-6">
	                            <textarea style="resize: vertical;" class="form-control" name="trans_eng"
	                            	rows="3"><?php echo e($manuscript->trans_eng); ?></textarea>
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Manuscript No.</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="manuscript_no"
	                            	value="<?php echo e($details['manuscript_no']); ?>">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Bab</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="bab" value="<?php echo e($details['bab']); ?>">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Page</label>

		                    <div class="col-sm-6">
	                            <input type="text" class="form-control" name="page" value="<?php echo e($details['page']); ?>">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <label for="field-1" class="col-sm-3 control-label">Image</label>

		                    <?php if($details['image']): ?>
		                    	<div class="col-sm-3">
			                    	<img src="<?php echo e(url('/public/uploads') . '/' . $details['image']); ?>" height="100" alt="">
			                    </div>
	                    	<?php endif; ?>

		                    <div class="<?php if($details['image']) echo 'col-sm-offset-3'; ?> col-sm-6">
	                            <input type="file" name="image" accept="image/*" style="margin-top: 7px;">
		                    </div>
		                </div>

		                <div class="form-group">
		                    <div class="col-sm-offset-3 col-sm-6">
		                        <button type="submit" class="btn btn-success">Update</button>
		                    </div>
		                </div>
	                </form>
	            </div>
	        </div>
	    </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>