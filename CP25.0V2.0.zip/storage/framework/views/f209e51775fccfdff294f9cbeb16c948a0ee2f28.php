<!DOCTYPE HTML>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Email Testing</title>
    </head>

    <body>
        <h1><?php echo e($title); ?></h1>

        <p><?php echo e($content); ?></p>
    </body>
</html>