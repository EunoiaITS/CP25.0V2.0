<?php $__env->startSection('content'); ?>

	<ol class="breadcrumb">
	  	<li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
	  	<li class="active">Manage Zikir</li>
	</ol>

	<?php if(Session::has('success_message')): ?>
        <p class="alert alert-success">
            <?php echo e(Session::get('success_message')); ?>

        </p>
    <?php endif; ?>

	<a href="<?php echo e(url('/admin/zikirs/create')); ?>" class="btn btn-primary pull-right" style="background: black;">
		<i class="fa fa-plus-circle"></i> Create New Zikir
	</a>
	<div class="clearfix"></div><br>

	<?php if($page_data['zikirs']->isEmpty()): ?>
		<p class="alert alert-info">
	        <?php echo e('No zikirs found!'); ?>

	    </p>
    <?php else: ?>
		<div class="panel panel-primary">
			<div class="panel-heading">
	    		<h3 class="panel-title">Zikir List</h3>
	  		</div>
			<div class="panel-body">
				<div class="table-responsive">
					<table id="example" class="table table-striped" style="width:100%">
				    	<thead>
				      		<tr>
				        		<th>#</th>
				        		<th>Zikir</th>
				        		<th>Options</th>
				      		</tr>
				    	</thead>
				    	<tbody>
				    		<?php
				    		$count = 1;
				      		foreach($page_data['zikirs'] as $zikir) {
				      			$details = [];
				      			
				      			foreach($zikir->details()->get() as $detail)
				      				$details[$detail->key] = $detail->value;
				      			?>
						      	<tr>
							        <td><?php echo $count++; ?></td>
							        <td><?php echo $zikir->title; ?></td>
							        <td>
							        	<a href="<?php echo e(url('/admin/zikirs/' . $zikir->id . '/edit')); ?>" class="btn btn-sm btn-default">
			                                Edit
			                            </a>
						        		<a href="#" class="btn btn-sm btn-danger"
											onclick="confirm_modal_hard_reload('<?php echo action('AdminZikirsController@destroy', $zikir->id); ?>');">
			                                Delete
			                            </a>
						        	</td>
						      	</tr>
					      	<?php } ?>
				    	</tbody>
				  	</table>
				</div>
			</div>
		</div>
	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>