<?php $__env->startSection('content'); ?>

	<ol class="breadcrumb">
	  	<li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
	  	<li class="active">Manage Hadith</li>
	</ol>

	<?php if(Session::has('success_message')): ?>
        <p class="alert alert-success">
            <?php echo e(Session::get('success_message')); ?>

        </p>
    <?php endif; ?>

	<a href="<?php echo e(url('/admin/hadiths/create')); ?>" class="btn btn-primary pull-right" style="background: black;">
		<i class="fa fa-plus-circle"></i> Create New Hadith
	</a>
	<div class="clearfix"></div><br>

	<?php if($page_data['hadiths']->isEmpty()): ?>
		<p class="alert alert-info">
	        <?php echo e('No hadiths found!'); ?>

	    </p>
    <?php else: ?>
		<div class="panel panel-primary">
			<div class="panel-heading">
	    		<h3 class="panel-title">Hadith List</h3>
	  		</div>
			<div class="panel-body">
				<div class="table-responsive">
					<table id="example" class="table table-striped" style="width:100%">
				    	<thead>
				      		<tr>
				        		<th>#</th>
				        		<th>Kitab</th>
				        		<th>Bab</th>
				        		<th>Vol</th>
				        		<th>Page</th>
				        		<th>Hadith No.</th>
				        		<th>Hadith (Arabic)</th>
				        		<th>Hadith (English)</th>
				        		<th>Hadith (Malay)</th>
				        		<th>Options</th>
				      		</tr>
				    	</thead>
				    	<tbody>
				    		<?php
				    		$count = 1;
				      		foreach($page_data['hadiths'] as $hadith) {
				      			$details = ['kitab' => '', 'bab' => '', 'vol' => '', 'page' => '',
				      				'hadith_no' => ''];
				      			
				      			foreach($hadith->details()->get() as $detail)
				      				$details[$detail->key] = $detail->value;
				      			?>
						      	<tr>
							        <td><?php echo $count++; ?></td>
							        <td><?php echo e($details['kitab']); ?></td>
							        <td><?php echo e($details['bab']); ?></td>
							        <td><?php echo e($details['vol']); ?></td>
							        <td><?php echo e($details['page']); ?></td>
							        <td><?php echo e($details['hadith_no']); ?></td>
							        <td><?php echo $hadith->trans_arabic; ?></td>
							        <td><?php echo $hadith->trans_eng; ?></td>
							        <td><?php echo $hadith->trans_malay; ?></td>
							        <td>
							        	<a href="<?php echo e(url('/admin/hadiths/' . $hadith->id . '/edit')); ?>" class="btn btn-sm btn-default">
			                                Edit
			                            </a>
						        		<a href="#" class="btn btn-sm btn-danger"
											onclick="confirm_modal_hard_reload('<?php echo action('AdminHadithsController@destroy', $hadith->id); ?>');">
			                                Delete
			                            </a>
						        	</td>
						      	</tr>
					      	<?php } ?>
				    	</tbody>
				  	</table>
				</div>
			</div>
		</div>
	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>