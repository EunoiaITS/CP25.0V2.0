<?php $__env->startSection('content'); ?>

	<ol class="breadcrumb">
	  	<li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
	  	<li class="active">Advertisements</li>
	</ol>

	<?php if(Session::has('success_message')): ?>
        <p class="alert alert-success">
            <?php echo e(Session::get('success_message')); ?>

        </p>
    <?php endif; ?>

	<a href="<?php echo e(url('/admin/advertisements/create')); ?>" class="btn btn-primary pull-right" style="background: black;">
		<i class="fa fa-plus-circle"></i> Create New Advertisement
	</a>
	<div class="clearfix"></div><br>

	<?php if($page_data['advertisements']->isEmpty()): ?>
		<p class="alert alert-info">
	        <?php echo e('No advertisements found!'); ?>

	    </p>
    <?php else: ?>
		<div class="panel panel-primary">
			<div class="panel-heading">
	    		<h3 class="panel-title">Advertisements List</h3>
	  		</div>
			<div class="panel-body">
				<div class="table-responsive">
					<table id="example" class="table table-striped" style="width:100%">
				    	<thead>
				      		<tr>
				        		<th>#</th>
				        		<th>Advertisement Image</th>
				        		<th>URL</th>
				        		<th>Options</th>
				      		</tr>
				    	</thead>
				    	<tbody>
				    		<?php
				    		$count = 1;
				      		foreach($page_data['advertisements'] as $advertisement) { ?>
						      	<tr>
							        <td><?php echo e($count++); ?></td>
							        <td>
							        	<?php if($advertisement->image): ?>
								        	<img src="<?php echo e(url('/public/uploads') . '/' . $advertisement->image); ?>"
								        		height="200" alt="">
						        		<?php endif; ?>
							    	</td>
							        <td><?php echo e($advertisement->url); ?></td>
							        <td>
							        	<a href="<?php echo e(url('/admin/advertisements/' . $advertisement->id . '/edit')); ?>" class="btn btn-sm btn-default">
			                                Edit
			                            </a>
						        		<a href="#" class="btn btn-sm btn-danger"
											onclick="confirm_modal_hard_reload('<?php echo action('AdminAdvertisementsController@destroy', $advertisement->id); ?>');">
			                                Delete
			                            </a>
						        	</td>
						      	</tr>
					      	<?php } ?>
				    	</tbody>
				  	</table>
				</div>
			</div>
		</div>
	<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>