<?php $__env->startSection('content'); ?>

	<div class="container-fluid">
    <div class="col-md-6 top10 col-md-offset-3">
        <h2>Company</h2>



<p>

        <h3> Company Registration No. 
NS0189929-X</h3>
    <br />
NAISSE HALL OF KNOWLEDGE
<br /><br />
Permanent Address of Company:<br />
Research and Innovation Management Centre,<br />
Level 4 Chancellery Building,<br />
Islamic Science University of Malaysia (USIM)<br />
71800, Bandar Baru Nilai,<br />
Negeri Sembilan,<br />
Malaysia<br />



        </p>



    </div>
    <!-- Col Md 8 -->



</div>
<!-- container fluid ends -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>