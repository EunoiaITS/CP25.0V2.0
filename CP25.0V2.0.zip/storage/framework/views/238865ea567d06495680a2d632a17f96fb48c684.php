<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml"
     xmlns:og="http://ogp.me/ns#"

xmlns:fb="http://www.facebook.com/2008/fbml">
<head>
    <meta charset="utf-8" />
    <title>Naqli Aqli</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <script
            src="https://code.jquery.com/jquery-2.2.4.min.js"
            integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
            crossorigin="anonymous"></script>

    <!-- Bootstrap Core CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    
    <link href="<?php echo e(asset('public/frontend/css/style1.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/frontend/css/ta.css')); ?>">
  <script>
      //document.addEventListener('contextmenu', event => event.preventDefault());
  </script>
</head>
<body>