<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="page-header">
                <h1>Register / Login<small></small></h1>
            </div>
        </div>
    </div>

    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li class="active">Register / Login</li>
    </ol>
    <div class="row">
        <div class="col-md-6">
            <h3>Login</h3>

            <?php if(session()->has('error-message')): ?>
              	<div class="alert alert-danger" role="alert">
              		<?php echo e(session()->get('error-message')); ?>

              	</div>
          	<?php endif; ?>

            <form action="<?php echo e(url('/user-login')); ?>" method="POST">
            	<?php echo csrf_field(); ?>
                <input type="email" class="form-control" placeholder="Email" required name="email" value="<?php echo e(old('email')); ?>">
                <br />
                <input type="password" class="form-control" placeholder="Password" required name="password">
                <br />
                <input type="hidden" class="form-control" name="role" value="subscriber">
                <input type="submit" name="submit" value="Login" class="btn btn-block btn-success" />
            </form>
        </div>
        <!-- left side of search ends -->

        <div class="col-md-6">
            <h3>Register</h3>

            <?php if(session()->has('success')): ?>
              	<div class="alert alert-success" role="success">
              		<?php echo e(session()->get('success')); ?>

              	</div>
          	<?php endif; ?>

          	<?php if(count($errors) > 0): ?>
                <div class="row" style="margin: 15px 0px;">
                    <ul class="alert alert-danger" role="alert">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li style="margin-left: 15px;"><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(url('/user-register')); ?>" method="POST">
            	<?php echo csrf_field(); ?>
            	<input type="text" class="form-control" placeholder="Name" required name="name" value="<?php echo e(old('name')); ?>">
                <br />
                <input type="email" class="form-control" placeholder="Email" required name="email" value="<?php echo e(old('email')); ?>">
                <br />
                <input type="password" class="form-control" placeholder="Password" required name="password">
                <br />
                <input type="password" class="form-control" placeholder="Retype Password" required name="password_confirmation">
                <br />
                <input type="hidden" class="form-control" name="role" value="subscriber">
                <input type="submit" name="submit" value="Register" class="btn btn-block btn-primary" />
            </form><br>
        </div>

    </div>
    <!-- right side of search ends -->
</div>
<!-- main row ends -->

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2>Refund and Cancellation Policy</h2>



            <p>

                <br />
                You may cancel a free trial anytime during the free trial period and incur no charge. For all initial purchases of subscriptions longer than one month, you may cancel during the first 10 days (calculated from the date of purchase plus the free trial period, if applicable) and receive a full refund. If the cancellation occurs after the first 10 days, you won’t be eligible for a refund. If you cancel your subscription but are not eligible for a refund, you’ll retain access to the subscription until it expires.
                <br /><br />
                For renewals of subscriptions longer than one month, cancel within seven days of the renewal date to receive a full refund. No refund is available for monthly subscriptions.
                <br /><br />
                To cancel your subscription, please complete the required fields in this form and include the following information in the description field:
                <br /><br />
                Username<br />
                Email address used when subscribing
                <br /><br />
                For more information, contact us at naisse.hall@gmail.com
            </p>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>